const NotFound = () => {
  return (
    <main className="NotFound">
      <div>🚨404 Error</div>
    </main>
  );
};

export default NotFound;
