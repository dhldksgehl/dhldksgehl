const MainPage = () => {
  return (
    <main className="MainPage">
      <div>여기는 홈!</div>
    </main>
  );
};

export default MainPage;
